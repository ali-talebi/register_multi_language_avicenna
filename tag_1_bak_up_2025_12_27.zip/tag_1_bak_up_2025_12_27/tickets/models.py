from django.db import models
from django.utils.translation import gettext_lazy as _

class Ticket(models.Model):
    LANGUAGE_CHOICES = [
        ('fa', _('فارسی / Persian')),
        ('ar', _('عربی / Arabic')),
        ('en', _('انگلیسی / English')),
    ]

    PRIORITY_CHOICES = [
        ('low', _('کم / Low')),
        ('medium', _('متوسط / Medium')),
        ('high', _('زیاد / High')),
    ]

    CATEGORY_CHOICES = [
        ('technical', _('فنی / Technical')),
        ('financial', _('مالی / Financial')),
        ('other', _('سایر / Other')),
    ]

    full_name = models.CharField(
        max_length=255,
        verbose_name=_('نام و نام خانوادگی / Full Name')
    )
    email = models.EmailField(
        verbose_name=_('ایمیل / Email')
    )
    subject = models.CharField(
        max_length=255,
        verbose_name=_('موضوع / Subject')
    )
    message = models.TextField(
        verbose_name=_('پیام / Message')
    )
    language = models.CharField(
        max_length=2,
        choices=LANGUAGE_CHOICES,
        default='fa',
        verbose_name=_('زبان / Language')
    )
    priority = models.CharField(
        max_length=10,
        choices=PRIORITY_CHOICES,
        default='medium',
        verbose_name=_('اولویت / Priority')
    )
    category = models.CharField(
        max_length=50,
        choices=CATEGORY_CHOICES,
        default='other',
        verbose_name=_('دسته بندی / Category')
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_('تاریخ ایجاد / Created At')
    )
    is_resolved = models.BooleanField(
        default=False,
        verbose_name=_('حل شده / Resolved')
    )
    
    time_created = models.DateTimeField(auto_now_add=True,null=True)
    

    class Meta:
        verbose_name = _('تیکت / Ticket')
        verbose_name_plural = _('تیکت‌ها / Tickets')
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.full_name} - {self.subject} ({self.email})"
