from django.contrib import admin
from .models import Ticket 
# Register your models here.

@admin.register(Ticket)
class Ticket_ADMIN(admin.ModelAdmin):
    list_display = ['full_name','email','subject','priority','category','is_resolved']
    list_filter = ['category','priority','is_resolved']
    search_fields = ['full_name',]
    list_editable = ['category','priority','is_resolved']