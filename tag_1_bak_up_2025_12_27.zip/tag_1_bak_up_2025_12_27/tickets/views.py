from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from django.utils.translation import gettext_lazy as _, activate
from .forms import TicketForm

SUPPORT_EMAILS = ['support@yourdomain.com']  # ایمیل پشتیبان‌ها

EMAIL_CONFIRMATION = {
    'fa': _('تیکت شما با موفقیت ثبت شد و تیم پشتیبانی در اسرع وقت پاسخ خواهد داد.'),
    'ar': _('تم تقديم تذكرتك بنجاح وسيرد فريق الدعم في أقرب وقت ممكن.'),
    'en': _('Your ticket has been submitted successfully and our support team will respond shortly.'),
}

def create_ticket(request):
    if request.method == 'POST':
        form = TicketForm(request.POST)
        if form.is_valid():
            ticket = form.save(commit=False)
            # زبان کاربر از session/کوکی هدر گرفته شود
            ticket.language = request.LANGUAGE_CODE
            ticket.save()

            # فعال کردن زبان برای پیام‌ها
            activate(ticket.language)

            # پیام موفقیت در فرم
            messages.success(
                request,
                _('تیکت شما با موفقیت ثبت شد! / تم تقديم تذكرتك بنجاح! / Your ticket has been submitted successfully!')
            )

            # ایمیل اطلاع‌رسانی به پشتیبان‌ها
            subject_admin = f"[New Ticket] {ticket.subject}"
            message_admin = f"""
نام و نام خانوادگی: {ticket.full_name}
ایمیل: {ticket.email}
موضوع: {ticket.subject}
پیام: {ticket.message}
زبان: {ticket.get_language_display()}
اولویت: {ticket.get_priority_display()}
دسته بندی: {ticket.get_category_display()}
"""
            # send_mail(subject_admin, message_admin, settings.DEFAULT_FROM_EMAIL, SUPPORT_EMAILS)

            # # ایمیل تایید به کاربر
            # send_mail(
            #     _('تایید ثبت تیکت / Ticket Confirmation'),
            #     EMAIL_CONFIRMATION.get(ticket.language, EMAIL_CONFIRMATION['en']),
            #     settings.DEFAULT_FROM_EMAIL,
            #     [ticket.email]
            # )

            return redirect('ticket_success')
    else:
        form = TicketForm()

    return render(request, 'tickets/create_ticket.html', {'form': form})

def ticket_success(request):
    return render(request, 'tickets/ticket_success.html', {
        'message': _('تیکت شما ثبت شد و تیم پشتیبانی در اسرع وقت پاسخ خواهد داد. / تم تقديم تذكرتك بنجاح وسيرد فريق الدعم في أقرب وقت ممكن. / Your ticket has been submitted and our support team will respond shortly.')
    })
