from django import forms
from django.utils.translation import gettext_lazy as _
from .models import Ticket

class TicketForm(forms.ModelForm):
    class Meta:
        model = Ticket
        # فیلد language را از فرم مخفی می‌کنیم
        fields = ['full_name', 'email', 'subject', 'message', 'priority', 'category']
        widgets = {
            'full_name': forms.TextInput(attrs={
                'placeholder': _('نام و نام خانوادگی / الاسم الكامل / Full Name')
            }),
            'email': forms.EmailInput(attrs={
                'placeholder': _('ایمیل / البريد الإلكتروني / Email')
            }),
            'subject': forms.TextInput(attrs={
                'placeholder': _('موضوع / الموضوع / Subject')
            }),
            'message': forms.Textarea(attrs={
                'placeholder': _('پیام شما / رسالتك / Your message'),
                'rows': 5
            }),
            'priority': forms.Select(),
            'category': forms.Select(),
        }
        labels = {
            'full_name': _('نام و نام خانوادگی / الاسم الكامل / Full Name'),
            'email': _('ایمیل / البريد الإلكتروني / Email'),
            'subject': _('موضوع / الموضوع / Subject'),
            'message': _('پیام / الرسالة / Message'),
            'priority': _('اولویت / الأولوية / Priority'),
            'category': _('دسته بندی / الفئة / Category'),
        }

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if not email:
            raise forms.ValidationError(
                _('لطفا ایمیل خود را وارد کنید. / يرجى إدخال البريد الإلكتروني الخاص بك. / Please enter your email.')
            )
        return email
