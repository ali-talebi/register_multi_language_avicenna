from django.urls import path
from . import views

urlpatterns = [
    path('tickets/', views.create_ticket, name='create_ticket'),
    path('tickets/success/', views.ticket_success, name='ticket_success'),
]